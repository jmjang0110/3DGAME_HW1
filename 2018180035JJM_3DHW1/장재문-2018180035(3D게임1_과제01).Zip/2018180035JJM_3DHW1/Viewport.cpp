#include "Viewport.h"


void CViewport::SetViewport(int nLeft, int nTop, int nWidth, int nHeight)
{

	m_nLeft   = nLeft;
	m_nTop    = nTop;
	m_nWidth  = nWidth;
	m_nHeight = nHeight;

}
