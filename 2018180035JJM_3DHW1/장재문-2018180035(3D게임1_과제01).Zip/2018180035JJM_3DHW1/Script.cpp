
#include "stdafx.h"
#include "Script.h"

CScript::CScript()
{
}

CScript::CScript(CGameObject* pOWner)
{
	m_pOwner = pOWner;

}

CScript::~CScript()
{
}

void CScript::Init()
{

}

void CScript::Update(float _fTimeElapsed)
{

}
