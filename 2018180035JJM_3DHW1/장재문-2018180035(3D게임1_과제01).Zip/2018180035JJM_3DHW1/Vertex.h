#pragma once

#include "stdafx.h"

class CVertex
{
public:
	XMFLOAT3    m_xmf3Position;

public:
	CVertex();
	CVertex(float x, float y, float z);
	~CVertex();

};
